<?php
/**
 * 
 * @file All the site backup functionality will go here.
 * 
 * */

// Security Check
if( !defined( 'ABSPATH' ) ) die();

if( !class_exists('SiteBackup') ):

/**
 * 
 * @class SiteBackup Main functionality of the site backup module
 * 
 * */
class SiteBackup{
	
	
	
}

endif;
