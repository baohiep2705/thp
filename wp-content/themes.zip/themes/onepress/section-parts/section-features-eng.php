<section id="doinguquanly" class="section-features section-padding section-meta onepage-section">
           		<div class="container">
                	<div class="section-title-area">
                    	<h2 class="section-title">MANAGEMENT TEAM</h2>
                        <div class="section-desc">
                        	<p>Meet our Senior Management Team. They guide our company in our quest to achieve two goals: top-tier financial performance and to make THP Beverage Group a great place to work.</p>
                        </div>
                    </div>
                    <div class="section-content">
                    	<div class="row">
                    	<div class="feature-item col-lg-6 col-sm-6 wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                            	<div class="feature-media">
                                	<a href="http://www.thp.com.vn/mr-tran-qui-thanh/">
                                    	<span class="icon-image"><img src="http://www.thp.com.vn/wp-content/uploads/2017/01/dr-thanh.png" /></span>
                                    </a>
                                </div>
                                <h4><a href="http://www.thp.com.vn/mr-tran-qui-thanh/">DR. THANH</a></h4>
                                <div class="feature-item-content"><p>CEO and Founder</p></div>
                            </div>
                        	<div class="feature-item col-lg-6 col-sm-6 wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                            	<div class="feature-media">
                                	<a href="http://www.thp.com.vn/ms-phuong-tran/">
                                    	<span class="icon-image"><img src="http://www.thp.com.vn/wp-content/uploads/2017/01/msphuong.jpg" /></span>
                                    </a>
                                </div>
                                <h4><a href="http://www.thp.com.vn/ms-phuong-tran/">Ms. PHUONG TRAN</a></h4>
                                <div class="feature-item-content"><p>Deputy CEO</p></div>
                            </div>
                            
                        </div>
                    </div>
                </div>
           </section>