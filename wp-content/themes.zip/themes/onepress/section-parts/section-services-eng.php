<section id="VIDEO" class="section-services section-padding section-meta onepage-section">
           		<div class="container">
                	<div class="section-title-area">
                    	<h2 class="section-title">VIDEO</h2>
                        <div class="section-desc">
                        	<p>From Youtube chanel</p>
                        </div>
                    </div> 
                    <div class="row">
                        	<div class="col-sm-6 col-lg-6 wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                            	<div class="service-item ">
                                	<a href="http://www.thp.com.vn/cnbc-thuc-hien-phong-su-dac-biet-ve-tan-hiep-phat/">
                                    	<span class="screen-reader-text">CNBC thực hiện phóng sự đặc biệt về Tân Hiệp Phát</span>                                    
                                     <div class="service-image icon-image"><img src="http://www.thp.com.vn/wp-content/uploads/2017/01/video-drthanh.jpg" /></div>
                                	<div class="service-content"><h4 class="service-title">CNBC thực hiện phóng sự đặc biệt về Tân Hiệp Phát</h4></div></a>
                                </div>                                
                               
                            </div>
                            <div class="col-sm-6 col-lg-6 wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                            	<div class="service-item ">
                                	<a href="http://www.thp.com.vn/ba-tran-uyen-phuong-nguoi-duoc-hy-vong-ke-thua-vi-tri-ceo-tan-hiep-phat/">
                                    	<span class="screen-reader-text">CNBC thực hiện phóng sự đặc biệt về Tân Hiệp Phát</span>                                    
                                     <div class="service-image icon-image"><img src="http://www.thp.com.vn/wp-content/uploads/2017/01/video-msphuong.jpg" /></div>
                                	<div class="service-content"><h4 class="service-title">Bà Trần Uyên Phương – Người được hy vọng kế thừa vị trí CEO Tân Hiệp Phát</h4></div></a>
                                </div>                                
                               
                            </div>
                        </div>                   
                </div>
           </section>