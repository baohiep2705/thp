<section id="thuonghieuviet" class="section-about section-padding onepage-section">
           		<div class="container">
                	<div class="section-title-area">
                    	<h2 class="section-title">NATIONAL BRANDS OF VIETNAM</h2>
                        <div class="section-desc">
                        	<p>See our National Brands</p>
                        </div>
                    </div>
                    <div class="row">
                    	<div class="col-lg-4 col-sm-6  wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                        	<div class="about-image">
                            	<a href="http://www.thp.com.vn/zero-degrees-green-tea-lemon/">
                                	<img class="attachment-post-thumbnail size-post-thumbnail wp-post-image" src="http://www.thp.com.vn/wp-content/uploads/2017/01/zero_degrees.jpg" />
                                </a>
                            </div>
                            <h3><a href="http://www.thp.com.vn/zero-degrees-green-tea-lemon/">Zero Degrees Green Tea with Lemon</a></h3>    
                            <p>Zero Degrees Lemon Green Tea is extracted from green tea leaves from Thai Nguyen highlands in the north of Vietnam where the climate...</p>                                                    
                        </div>
                        <div class="col-lg-4 col-sm-6  wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                        	<div class="about-image">
                            	<a href="http://www.thp.com.vn/dr-thanh-herbal-tea/">
                                	<img class="attachment-post-thumbnail size-post-thumbnail wp-post-image" src="http://www.thp.com.vn/wp-content/uploads/2017/01/dt_herbal-tea.jpg" />
                                </a>
                            </div>
                            <h3><a href="http://www.thp.com.vn/dr-thanh-herbal-tea/">Dr. Thanh Herbal Tea</a></h3>   
                            <p>Made from a combination of nine different herbs, Dr Thanh Herbal Tea has been especially developed to help you relieve inner health when ...</p>                                                     
                        </div>
                        <div class="col-lg-4 col-sm-6  wow slideInUp" style="visibility: visible; animation-name: slideInUp;">
                        	<div class="about-image">
                            	<a href="http://www.thp.com.vn/number-1-energy-drink/">
                                	<img class="attachment-post-thumbnail size-post-thumbnail wp-post-image" src="http://www.thp.com.vn/wp-content/uploads/2017/01/number1energy.jpg" />
                                </a>
                            </div>
                            <h3><a href="http://www.thp.com.vn/number-1-energy-drink/">Number 1 Energy Drink</a></h3>   
                            <p>Vietnam's leading energy drink, Number 1 Energy Drink is made from a combination of vitamin B3, taurine, inositol and caffeine ...</p>                                                     
                        </div>
                    </div>
                </div>
           </section>
           